PAYFLOW Android Wrapper
========================

This project wraps the original PAYFLOW web application inside an Android WebView.

Important:
- Original PAYFLOW files are copied into app/src/main/assets/payflow.
- No Firebase configuration, application data, or original UI files are intentionally modified.
- Build with Android Studio / Gradle to produce an APK.
- Open the generated APK on Android and install it; PAYFLOW will appear as an Android app.

Build:
1. Open the PAYFLOW-Android folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
