# PAYFLOW — Build APK from a phone

This package is prepared for cloud building. It keeps the original PAYFLOW web app under
`app/src/main/assets/payflow/`.

## Build with GitHub from Android only

1. Create/sign in to a GitHub account in Chrome.
2. Create a new **private repository**.
3. Upload the contents of this `PAYFLOW-Android` folder to the repository (not the ZIP itself).
4. Open **Actions** → **Build PAYFLOW APK** → **Run workflow**.
5. When the workflow finishes, open the run → **Artifacts** → `PAYFLOW-debug-apk`.
6. Download the ZIP, extract it, then install `app-debug.apk` on Android.

The generated APK is a debug APK for personal installation/testing.

Important:
- No PAYFLOW data files are intentionally changed.
- Firebase configuration is kept as supplied by the original project.
- The launcher icon uses the existing PAYFLOW icon.
